#ifndef JAIL_H
#define JAIL_H

class Jail
{
public:

    Jail();
};

#endif // JAIL_H
